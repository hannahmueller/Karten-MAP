import json

# Read the JSON file
def read_json_file(file_path):
    with open(file_path, 'r') as file:
        data = json.load(file)
    return data

# JSON file path
file_path = 'journal_batch_1_cleaned.json'  # Replace with your file path

# Reading JSON file
json_data = read_json_file(file_path)


x = 0

Datav2 = []
for entry in json_data:
    keywords = entry.get('bibjson', {}).get('keywords', [])

    for word in keywords:
        if 'philosophy' in word:
            print(f"'philosophy' found in: {word}")
            print(entry)
            Datav2.append(entry)

with open('updated_journal_batch_only_phil.json', 'w') as outfile:
    json.dump(Datav2, outfile, indent=2)

