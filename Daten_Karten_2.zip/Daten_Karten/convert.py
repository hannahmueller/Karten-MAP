import json

def decode_text_in_json(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        data = json.load(file)

    decoded_data = []
    for item in data:
        decoded_item = {}
        for key, value in item.items():
            if isinstance(value, str):
                decoded_item[key] = value.encode().decode('unicode-escape')
            else:
                decoded_item[key] = value  # Behalte andere Datentypen unverändert
        decoded_data.append(decoded_item)

    return decoded_data

def save_to_json(data, output_file):
    with open(output_file, 'w', encoding='utf-8') as file:
        json.dump(data, file, ensure_ascii=False, indent=4)

# Beispiel: Angenommen, die JSON-Datei heißt 'data.json'
input_file_path = 'journal_batch_1.json'
output_file_path = 'journal_batch_1_cleaned.json'

decoded_content = decode_text_in_json(input_file_path)

# Speichere den dekodierten Inhalt in einer neuen JSON-Datei
save_to_json(decoded_content, output_file_path)
