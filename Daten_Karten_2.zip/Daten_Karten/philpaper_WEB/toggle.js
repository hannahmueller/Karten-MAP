var requestURL;

console.log("toggle.js");

var publURL = "daten/DOAJ_Publisher.json";
var instURL = "daten/DOAJ_Institution.json";

function toggle() {
    console.log("toggle()");

    markers.clearLayers();
    if (requestURL == publURL) {
        console.log("requestURL == publURL -> True");
        console.log("requestURL: " + requestURL);
        requestURL = instURL;
        loadData();
    } else {
        console.log("requestURL == publURL -> False");
        console.log("requestURL: " + requestURL);
        requestURL = publURL;
        loadData();
    }
}

