var southWest = L.latLng(-89.0, -180),
    northEast = L.latLng(89.0, 180),
    bounds = L.latLngBounds(southWest, northEast);

var map = L.map('map', {
    center: [0, 0],
    zoom: 2,
    maxBounds: bounds,

});

L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
}).addTo(map);

var markers = L.markerClusterGroup();
var locations;
var uniqueCountries = new Set();

var requestURL = 'daten/DOAJ_Publisher.json';

function loadData() {

    var request = new XMLHttpRequest();
    request.open('GET', requestURL, true);
    request.responseType = 'json';

    request.onload = function () {
        if (request.status === 200) {
            locations = request.response;

            document.getElementById("datenID").textContent = "Data: " + requestURL;

            locations.forEach(function (entry) {
                if (entry.bibjson.location && entry.bibjson.location.lat && entry.bibjson.location.long) {
                    var lat = parseFloat(entry.bibjson.location.lat);
                    var long = parseFloat(entry.bibjson.location.long);
                    var marker = L.marker([lat, long]);
                    marker.on('click', function () {
                        updateInfoBox(entry.bibjson);
                    });
                    markers.addLayer(marker);


                    var country = entry.bibjson.institution?.country || entry.bibjson.publisher?.country;
                    if (country) {
                        uniqueCountries.add(country);
                    }
                }
            });

            fillCountryDropdown(Array.from(uniqueCountries));
            map.addLayer(markers);
        }
    };

    request.send();
}

loadData();

function updateMarkersByCountry(selectedCountry) {
    markers.clearLayers();

    locations.forEach(function (entry) {
        var entryCountry = entry.bibjson.institution?.country || entry.bibjson.publisher?.country;

        if (entry.bibjson.location && typeof entry.bibjson.location.lat !== 'undefined' && typeof entry.bibjson.location.long !== 'undefined') {
            var lat = parseFloat(entry.bibjson.location.lat);
            var long = parseFloat(entry.bibjson.location.long);
            if (!isNaN(lat) && !isNaN(long)) {

                if (selectedCountry === "" || entryCountry === selectedCountry) {
                    var marker = L.marker([lat, long]);
                    marker.on('click', function () {
                        updateInfoBox(entry.bibjson);
                    });
                    markers.addLayer(marker);
                }
            }
        }
    });
}



function fillCountryDropdown(countriesArray) {
    var dropdown = document.getElementById('countryFilter');
    countriesArray.sort();
    countriesArray.forEach(function (country) {
        var option = document.createElement('option');
        option.value = option.textContent = country;
        dropdown.appendChild(option);
    });
}

document.getElementById('countryFilter').addEventListener('change', function () {
    updateMarkersByCountry(this.value);
});



function updateInfoBox(bibjson) {
    var infoBox = document.getElementById('info-box2');
    var content = '<p>' + "Journal: " + bibjson.title + '<p>';
    content += '<p>' + "Language: " + bibjson.language + '<p>';

    // Prüfen, ob bibjson.institution und bibjson.institution.name existieren
    if (bibjson.institution && bibjson.institution.name) {
        content += '<p>' + "Institution: " + bibjson.institution.name + '<p>';
    } else {
        // Fallback, falls die Institution oder der Name nicht vorhanden ist
        content += '<p>' + "Institution: Informationen nicht verfügbar" + '<p>';
    }

    if (bibjson.eissn) {
        var eissnLink = 'https://portal.issn.org/resource/ISSN/' + bibjson.eissn;
        content += '<p><a href="' + eissnLink + '" target="_blank">To the Publikation (eISSN: ' + bibjson.eissn + ')</a></p>';
    }

    if (bibjson.pissn) {
        var pissnLink = 'https://portal.issn.org/resource/ISSN/' + bibjson.pissn;
        content += '<p><a href="' + pissnLink + '" target="_blank">To the Publication (pISSN: ' + bibjson.pissn + ')</a></p>';
    }

    var ubKoelnLinkBase = 'https://katalog.ub.uni-koeln.de/portal/search.html?num=20&page=1&l=de&sort=relevance_desc&st=1&tab=books&profile=4772819&fs=';
    var issnForUbKoeln = bibjson.pissn || bibjson.eissn;
    if (issnForUbKoeln) {
        var ubKoelnLink = ubKoelnLinkBase + issnForUbKoeln;
        content += '<p><a href="' + ubKoelnLink + '" target="_blank">UB Köln Search (ISSN: ' + issnForUbKoeln + ')</a></p>';
    }



    document.getElementById('info-content').innerHTML = content;
}



function searchByKeyword() {
    var input = document.getElementById('keywordSearch').value.trim().toLowerCase();
    markers.clearLayers();

    locations.forEach(function (entry) {
        if (entry.bibjson.keywords) {
            var keywords = entry.bibjson.keywords.map(function (keyword) { return keyword.toLowerCase(); });
            if (keywords.includes(input)) {
                var lat = parseFloat(entry.bibjson.location.lat);
                var long = parseFloat(entry.bibjson.location.long);
                var marker = L.marker([lat, long]).addTo(markers);
                marker.on('click', function () {
                    updateInfoBox(entry.bibjson);
                });
            }
        }
    });

    if (markers.getLayers().length === 0) {
        alert('Keine Ergebnisse für das gesuchte Keyword gefunden.');
    }
}



function searchByKeyword() {
    var input = document.getElementById('keywordSearch').value.trim().toLowerCase();
    markers.clearLayers();

    locations.forEach(function (entry) {
        if (entry.bibjson.keywords) {
            var keywords = entry.bibjson.keywords.map(function (keyword) { return keyword.toLowerCase(); });
            if (keywords.includes(input)) {
                var lat = parseFloat(entry.bibjson.location.lat);
                var long = parseFloat(entry.bibjson.location.long);
                var marker = L.marker([lat, long]).addTo(markers);
                marker.on('click', function () {
                    updateInfoBox(entry.bibjson);
                });
            }
        }
    });

    if (markers.getLayers().length === 0) {
        alert('Keine Ergebnisse für das gesuchte Keyword gefunden.');
    }
}


